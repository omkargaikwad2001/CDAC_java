import java.util.*;
public class Pattern3{
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);	
		
		System.out.println("Enter number ");
		int n=sc.nextInt();

		for(int i=1;i<=n;i++){

			//print space
			for(int j=n;j>i;j--){
				System.out.print(" ");
			}

			//print *
			for(int j=1;j<=i;j++){
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}