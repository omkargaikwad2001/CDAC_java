package utility;

public interface ITraveller {
	
	String getPassportDetails();
	int getTraverHours();

}
