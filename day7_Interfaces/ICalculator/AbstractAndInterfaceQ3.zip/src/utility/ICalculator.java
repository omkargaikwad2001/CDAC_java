package utility;

public interface ICalculator {
	
	double add(float a,float b);
	double sub(float a,float b);
	double mul(float a,float b);
	double div(float a,float b);

}
