package util;

public interface BasicIntOperations {
	
	public boolean isOdd(int n);
	public boolean isEven(int n);

}
