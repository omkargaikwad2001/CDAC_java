package util;

public interface AdvanceIntOperations {
	
	public boolean isPrime(int n);
	public double calFactorial(int n);

}
