package util;

public interface Compare {
	
	public int compare(Object o1,Object o2);

}
