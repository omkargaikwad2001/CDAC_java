package app;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Prog Started...");
		
		System.out.println("Thread Name = "+Thread.currentThread().getName());
		System.out.println("Thread Priority = "+Thread.currentThread().getPriority());
		
		System.out.println("Prog Ended...");

	}

}
