package util;

public class PasswordToShortException extends RuntimeException{
	
	public PasswordToShortException(String msg) {
		super(msg);
	}

}
