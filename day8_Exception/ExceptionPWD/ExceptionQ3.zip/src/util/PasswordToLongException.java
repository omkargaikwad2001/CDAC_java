package util;

public class PasswordToLongException extends RuntimeException{
	
	public PasswordToLongException(String msg){
		super(msg);
	}
	

}
