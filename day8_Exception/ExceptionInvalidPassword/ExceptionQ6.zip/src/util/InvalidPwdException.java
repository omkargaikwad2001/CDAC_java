package util;

public class InvalidPwdException extends Exception {
    public InvalidPwdException(String message) {
        super(message);
    }
}
