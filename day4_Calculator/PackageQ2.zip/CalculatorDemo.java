import utility.math.Calculator;
public class CalculatorDemo{
	
	public static void main(String[] args){
		
		Calculator.add();
		Calculator.subtract();
		
	}

}