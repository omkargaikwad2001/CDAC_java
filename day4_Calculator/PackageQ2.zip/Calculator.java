package utility.math;
public class Calculator{
	
	private static int n1=10;
	private static int n2=20;
	
	public static void add(){
		System.out.println("Addition = "+(n1+n2));
	}

	public static void subtract(){
		System.out.println("Subtraction = "+(n1-n2));
	}	

	

}